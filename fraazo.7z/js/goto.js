function gotoabt() {
  window.scroll({
    top: 5320,
    left: 0,
    behavior: "smooth",
  });
  behavior: "smooth";
}
function gotoreg() {
  window.location.href = "signup.html";
}
function gotocart() {
  window.location.href = "frz-cart.html";
}
function gotologin() {
  window.location.href = "signin.html";
}
function gotoindex() {
  window.location.href = "index.html";
}

function gotoAdd() {
  window.location.href = "frz-adrs.html";
}
function gotoPay() {
  window.location.href = "payment.html";
}
function gotoMap() {
  window.open("https://maps.google.com", "_blank");
}
